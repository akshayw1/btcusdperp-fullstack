import About from "@/components/about/about";

export default function Page() {
  return <About />;
}
