import UsersTable from "@/components/usersTable/usersTable";
export default function Page() {
  return <UsersTable />;
}
