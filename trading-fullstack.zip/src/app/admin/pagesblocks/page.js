import PagesTable from "@/components/pagesBlocksTable/pagesTable";
export default function Page() {
  return <PagesTable />;
}
