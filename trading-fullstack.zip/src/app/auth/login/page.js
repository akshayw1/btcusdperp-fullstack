import Login from "@/components/login/login";

export default function Page() {
  return <Login />;
}
