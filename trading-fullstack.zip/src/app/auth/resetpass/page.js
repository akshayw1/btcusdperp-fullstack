import Reset from "@/components/reset/reset";

export default function Page() {
  return <Reset />;
}
