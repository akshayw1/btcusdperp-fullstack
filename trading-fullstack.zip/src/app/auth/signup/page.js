import SignUp from "@/components/signup/signup";

export default function Page() {
  return <SignUp />;
}
