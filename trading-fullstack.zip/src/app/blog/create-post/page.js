import BlogCreatorPost from "@/components/blog/blogCreatePost/blogCreatorPost";

export default function Page() {
  return <BlogCreatorPost />;
}
