import Blog from "@/components/blog/blog";
export default function Page() {
  return <Blog />;
}
