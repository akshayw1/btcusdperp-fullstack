import Careers from "../../components/careers/careers";

export default function Page() {
  return <Careers />;
}
