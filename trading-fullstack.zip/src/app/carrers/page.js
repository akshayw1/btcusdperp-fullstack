import React from 'react'
import Carrers from '../../components/carrers/carrers'

const page = () => {
  return (
    <div>
        <Carrers/>


    </div>
  )
}

export default page