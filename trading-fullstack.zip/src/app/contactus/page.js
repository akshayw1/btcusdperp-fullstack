import ContactUs from "@/components/contactus/contactus";
export default function Home() {
  return <ContactUs />;
}
