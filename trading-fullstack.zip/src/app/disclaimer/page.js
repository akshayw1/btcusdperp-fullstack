import Disclaimer from "../../components/disclaimer/disclaimer";
export default function Page() {
  return <Disclaimer></Disclaimer>;
}
