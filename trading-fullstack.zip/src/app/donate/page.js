import Donate from "@/components/donate/donate";

export default function Page() {
  return <Donate />;
}
