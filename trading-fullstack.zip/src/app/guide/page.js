import Guide from "@/components/guide/guide";

export default function Page() {
  return <Guide />;
}
