import Home from "../components/home/home";

export default function Page() {
  return <Home />;
}
