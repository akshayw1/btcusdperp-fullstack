import Privacy from "@/components/privacy/privacy";
export default function Page() {
  return <Privacy />;
}
