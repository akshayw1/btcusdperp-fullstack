import React from 'react'
import Terms from '../../components/terms/terms'

const TermsandCond = () => {
  return (
    <div><Terms/>
    
    dsfdsfs</div>
  )
}

export default TermsandCond