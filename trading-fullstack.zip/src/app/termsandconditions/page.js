import Terms from '@/components/terms/terms'
import React from 'react'

const TermsandConditions = () => {
  return (
    <div>
        <Terms/>
    </div>
  )
}

export default TermsandConditions