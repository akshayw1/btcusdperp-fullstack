import FutureOI from "@/components/futureOI/futureOI";

export default function Page({ params }) {
  return <FutureOI nameoi={params.nameoi} />;
}
