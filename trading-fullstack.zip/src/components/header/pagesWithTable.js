const pagesWithTable = [
  "/user/bitcoin",
  "/admin/allusers",
  "/user/ethereum",
  "/user/cosmos",
  "/user/avalaunch",
  "/user/solona",
  "/user/sui",
  "/user/injective",
  "/admin/pagesblocks",
];
export default pagesWithTable;
