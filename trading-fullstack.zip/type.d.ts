declare module "chartjs-adapter-date-fns";
